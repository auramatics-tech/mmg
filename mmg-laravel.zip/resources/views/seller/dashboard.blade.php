@extends('seller.layouts.master')
@section('content')

@endsection